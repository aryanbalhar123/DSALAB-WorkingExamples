import java.util.*;

public class EmergencyTravelPlan {

    // Class representing a node in the travel graph
    public static class Node implements Comparable<Node> {
        int city;  // City represented by the node
        int days;  // Number of days to reach the city

        public Node(int city, int days) {
            this.city = city;
            this.days = days;
        }

        // Compare nodes based on the number of days (priority on fewer days)
        @Override
        public int compareTo(Node other) {
            return Integer.compare(this.days, other.days);
        }
    }

    // Function to calculate the minimum number of days to reach the destination city
    public static int calculateMinimumDays(int totalCities, List<int[]> aerialConnections) {
        // Create an adjacency list representation of the travel graph
        List<int[]>[] graph = new ArrayList[totalCities];
        for (int i = 0; i < totalCities; i++) {
            graph[i] = new ArrayList<>();
        }

        // Add connections for traveling up to 6 cities within a day
        for (int i = 0; i < totalCities; i++) {
            for (int j = 1; j <= 6 && i + j < totalCities; j++) {
                graph[i].add(new int[]{i + j, 1});  // Travel time = 1 day
            }
        }

        // Include aerial routes with zero travel time
        for (int[] route : aerialConnections) {
            int source = route[0];
            int destination = route[1];
            graph[source].add(new int[]{destination, 0});  // Travel time = 0 days
        }

        // Use a priority queue to prioritize nodes with fewer travel days
        PriorityQueue<Node> priorityQueue = new PriorityQueue<>();
        boolean[] visited = new boolean[totalCities];
        priorityQueue.add(new Node(0, 0));  // Start from city 0 with 0 days

        while (!priorityQueue.isEmpty()) {
            Node current = priorityQueue.poll();
            int currentCity = current.city;
            int currentDays = current.days;

            // If the destination city is reached, return the travel days
            if (currentCity == totalCities - 1) {
                return currentDays;
            }

            if (visited[currentCity]) continue;
            visited[currentCity] = true;

            // Explore neighboring cities
            for (int[] neighbor : graph[currentCity]) {
                int nextCity = neighbor[0];
                int travelDays = neighbor[1];
                if (!visited[nextCity]) {
                    priorityQueue.add(new Node(nextCity, currentDays + travelDays));
                }
            }
        }

        // Destination city unreachable
        return -1;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of test cases: ");
        int testCases = input.nextInt();

        while (testCases-- > 0) {
            System.out.print("Enter the total number of cities: ");
            int totalCities = input.nextInt();

            System.out.print("Enter the number of aerial connections: ");
            int connectionCount = input.nextInt();

            List<int[]> aerialConnections = new ArrayList<>();
            for (int i = 0; i < connectionCount; i++) {
                System.out.print("Enter the source and destination for connection " + (i + 1) + ": ");
                int source = input.nextInt();
                int destination = input.nextInt();
                aerialConnections.add(new int[]{source, destination});
            }

            // Calculate and display minimum travel days
            int minimumDays = calculateMinimumDays(totalCities, aerialConnections);
            if (minimumDays != -1) {
                System.out.println("Minimum days required: " + minimumDays);
            } else {
                System.out.println("The destination city cannot be reached.");
            }
        }

        input.close();
    }
}
