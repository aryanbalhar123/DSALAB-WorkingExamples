import java.util.Scanner;

public class DiagonalSum {

    public static int leftDiagonalSum(int[][] matrix) {
        int sum = 0;
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    public static int rightDiagonalSum(int[][] matrix) {
        int sum = 0;
        int n = matrix.length; // Size of the square matrix
        for (int i = 0; i < n; i++) {
            sum += matrix[i][n - 1 - i]; // Accessing right diagonal elements
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the square matrix (n x n): ");
        int n = scanner.nextInt();

        int[][] matrix = new int[n][n];

        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }

        int leftSum = leftDiagonalSum(matrix);
        int rightSum = rightDiagonalSum(matrix);

        System.out.println("Left Diagonal Sum: " + leftSum);
        System.out.println("Right Diagonal Sum: " + rightSum);

        scanner.close();
    }
}
