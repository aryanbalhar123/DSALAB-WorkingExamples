class TreeNode{
    int data;
    TreeNode left,right;
    TreeNode(int data){
        this.data =data;
        left =right =null;
    }}
public class BinaryTreeTasks {
    public static int calculateLevel(TreeNode root) {
        if (root ==null) {
            return 0;}
        int leftDepth =calculateLevel(root.left);
        int rightDepth =calculateLevel(root.right);
        return Math.max(leftDepth, rightDepth) +1;
    }
    public static boolean isCompleteTree(TreeNode root) {
        if (root ==null) {
            return true;
        }
        boolean end =false;
        java.util.Queue<TreeNode> queue =new java.util.LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();
            if (current ==null) {
                end =true;
            } else {
                if (end) {
                    return false;}
                queue.add(current.left);
                queue.add(current.right);
            }}
        return true;}
    public static boolean isFullTree(TreeNode root) {
        if (root == null) {
            return true;}
        if ((root.left == null && root.right != null) || (root.left != null && root.right == null)) {
            return false;}
        return isFullTree(root.left) && isFullTree(root.right);}
    public static boolean checkChildrenSumProperty(TreeNode root) {
        if (root == null || (root.left == null && root.right == null)) {
            return true;}
        int leftData = (root.left != null) ? root.left.data : 0;
        int rightData = (root.right != null) ? root.right.data : 0;
        return (root.data == leftData + rightData) &&
                checkChildrenSumProperty(root.left) &&
                checkChildrenSumProperty(root.right);
    }
    public static void main(String[] args) {
        TreeNode root=new TreeNode(10);
        root.left=new TreeNode(8);
        root.right=new TreeNode(2);
        root.left.left=new TreeNode(3);
        root.left.right=new TreeNode(5);
        root.right.right=new TreeNode(2);
        System.out.println("level of the binary tree:"+calculateLevel(root));
        System.out.println("is the binary tree complete?"+isCompleteTree(root));
        System.out.println("is the binary tree full?"+isFullTree(root));
        System.out.println("does the binary tree satisfy the children sum property?"+checkChildrenSumProperty(root));
    }
}
